package com.example.project2;

import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.BaseAdapter;
import java.util.ArrayList;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
public class GridAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<ItemModel> items; // used for item list
    private InventoryHelper database; // database helper

    public GridAdapter(Context context, ArrayList<ItemModel> items, InventoryHelper database) {
        this.context = context;
        this.items = items;
        this.database = database;
    }

    @Override
    public int getCount() {
        return items.size();
    } // for number of items

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.grid_items, parent, false);
        }
        ItemModel item = items.get(position);

        Button delete = convertView.findViewById(R.id.buttonDelete); // used to delete buttons from list
        Button increment = convertView.findViewById(R.id.buttonIncrement); // used to increment item quantities
        Button decrement = convertView.findViewById(R.id.buttonDecrement); // used to decrement item quantities
        TextView quantityView = convertView.findViewById(R.id.itemQuantity);
        quantityView.setText(String.valueOf(item.quantity));

        delete.setOnClickListener(view -> {
            if (database.deleteItem(item.id)) {
                items.remove(item);
                notifyDataSetChanged();
            }
        });
        increment.setOnClickListener(view -> { // renamed for enhancement, used to add by 1
            if (database.incrementItem(item.id, item.name, item.quantity)) {
                item.quantity = item.quantity + 1;
                notifyDataSetChanged();
            }
        });
        decrement.setOnClickListener(view -> { // added for enhancement, used to subtract by 1
            if (database.decrementItem(item.id, item.name, item.quantity)) {
                item.quantity = item.quantity - 1;
                notifyDataSetChanged();
            }
        });

        EditText itemEdit = convertView.findViewById(R.id.itemName);
        itemEdit.setText(item.name);
        itemEdit.setEnabled(false);

        Button rename = convertView.findViewById(R.id.buttonRename);
        rename.setOnClickListener(view -> {
            itemEdit.setEnabled(true);
            itemEdit.requestFocus();
            itemEdit.setSelection(itemEdit.getText().length());
        });

        itemEdit.setOnFocusChangeListener((v, hasFocus) -> { // added for saving the updated item name
            if (hasFocus == false) {
               String updatedName = itemEdit.getText().toString();

               if (database.itemEstablished(updatedName)) {
                   itemEdit.setEnabled(false);
                   return;
               }

               item.name = updatedName;

               database.updateItem(item.id, updatedName, item.quantity);
               itemEdit.setEnabled(false);
            }
        });
        return convertView;
    }
}


