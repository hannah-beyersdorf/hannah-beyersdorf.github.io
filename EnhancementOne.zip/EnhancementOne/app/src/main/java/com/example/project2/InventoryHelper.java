package com.example.project2;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.content.Context;
import android.content.ContentValues;

public class InventoryHelper extends SQLiteOpenHelper {
// variables
    private static final String TABLE_ITEMS = "items";
    private static final String COL_ITEM_ID = "id";
    private static final String COL_ITEM_QUANTITY = "quantity";
    private static final String COL_ITEM_NAME = "name";
    private static final String DATABASE_NAME = "inventory";
    private static final String TABLE_USERS = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";
    private static final String COL_USER_ID = "id";

  public InventoryHelper(Context context) {
      super(context,DATABASE_NAME, null, 1);

    }
    @Override // database created
    public void onCreate(SQLiteDatabase database) {
     String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
             COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
             COL_USERNAME + " TEXT, " +
             COL_PASSWORD + " TEXT) ";
     database.execSQL(createUsers);

        String createItems = "CREATE TABLE " + TABLE_ITEMS + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_ITEM_QUANTITY + " INTEGER) ";
        database.execSQL(createItems);

  }
    @Override
    public void onUpgrade(SQLiteDatabase database, int oldItem, int newItem) {
      onCreate(database);

    }
    public boolean createUser(String username, String password) { // user creation
      SQLiteDatabase inventoryDatabase = getWritableDatabase();
      ContentValues values = new ContentValues();
      values.put(COL_USERNAME, username);
      values.put(COL_PASSWORD, password);
        return inventoryDatabase.insert(TABLE_USERS, null, values) != -1;
    }
    public Cursor getItems() {
      SQLiteDatabase database = getReadableDatabase();
      return database.query(TABLE_ITEMS, null, null, null, null,null,null);
    }
    public boolean loginUser(String username, String password) {
        SQLiteDatabase inventoryDatabase = getReadableDatabase();
        Cursor cursor = inventoryDatabase.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ? and " + COL_PASSWORD + " = ?" , new String[]{username, password}, null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;

    }
    public boolean addItem(String itemName, int itemQuantity) {
        if (itemEstablished(itemName)) {
            return false;
        }
        SQLiteDatabase inventoryDatabase = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, itemName);
        values.put(COL_ITEM_QUANTITY, itemQuantity);
        return inventoryDatabase.insert(TABLE_ITEMS, null, values) != -1;
    }
    public boolean updateItem(long id, String name, int quantity) {
        SQLiteDatabase inventoryDatabase = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QUANTITY, quantity);
        int rows = inventoryDatabase.update(TABLE_ITEMS, values,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean itemEstablished(String name) {
        SQLiteDatabase inventoryDatabase = getReadableDatabase();
        Cursor cursor = inventoryDatabase.query("items", new String[]{"id"}, "name = ?",
                new String[]{name}, null, null, null);
        boolean established = cursor.moveToFirst();
        cursor.close();
        return established;

    }

    public boolean incrementItem(long id, String name, int quantity) { // renamed from updateItem to incrementItem for enhancement
        SQLiteDatabase inventoryDatabase = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QUANTITY, quantity);
        int rows = inventoryDatabase.update(TABLE_ITEMS, values, COL_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean decrementItem(long id, String name, int quantity) { // added for enhancement to subtract item quantity by 1
        SQLiteDatabase inventoryDatabase = getWritableDatabase();
        Cursor cursor = inventoryDatabase.query(
                TABLE_ITEMS, new String[]{COL_ITEM_NAME, COL_ITEM_QUANTITY}, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)},
                null, null, null);

        if (cursor.moveToFirst()) {
            int currentQuantity = cursor.getInt(cursor.getColumnIndex(COL_ITEM_QUANTITY));
            if (currentQuantity <= 0) {
                cursor.close();
                return false;
            }

           int newQuantity = currentQuantity - 1;
           ContentValues values = new ContentValues();
           values.put(COL_ITEM_QUANTITY, newQuantity);
           int rows = inventoryDatabase.update(TABLE_ITEMS, values,COL_ITEM_ID+ " = ?",
                   new String[]{String.valueOf(id)});
           cursor.close();
           return rows > 0;

        } else {
            cursor.close();
            return false;
        }


    }
    public boolean deleteItem(long id) {
        SQLiteDatabase inventoryDatabase = getWritableDatabase();
        int rows = inventoryDatabase.delete(TABLE_ITEMS, COL_ITEM_ID+ " = ?",
                new String[]{String.valueOf(id)});
        return rows > 0;
    }
}
