package com.example.project2;

public class ItemModel {
    public long id;
    public long categoryId;

    public String name;
    public int quantity;
    public ItemModel(long id, String name, int quantity, long categoryId) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.categoryId = categoryId;

    }
}
