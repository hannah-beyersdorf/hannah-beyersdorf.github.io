package com.example.project2;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.GridView;
import android.database.Cursor;
import android.widget.Toast;
import android.telephony.SmsManager;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity; // for buttons and text
public class InventoryActivity extends AppCompatActivity {
    private Button buttonAdd;
    private Button buttonLogout;

    private Button buttonSort; // sort button added for enhancement

    private Button buttonAddCategory; // added for categories

    private EditText addCategory;

    private EditText addItem;
    private GridView gridView;
    private EditText addQuantity;
    private InventoryHelper database;
    private GridAdapter adapter;
    private ArrayList<ItemModel> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonLogout = findViewById(R.id.buttonLogout);
        buttonSort = findViewById(R.id.buttonSort); // added for enhancement
        addItem = findViewById(R.id.addItem);
        gridView = findViewById(R.id.gridView);
        addQuantity = findViewById(R.id.addQuantity);
        addCategory = findViewById(R.id.addCategory);
        buttonAddCategory = findViewById(R.id.buttonAddCategory);


        items = new ArrayList<>();
        database = new InventoryHelper(this);

        adapter = new GridAdapter(this, items, database);
        gridView.setAdapter(adapter);
        loadItems();


        buttonAdd.setOnClickListener(new View.OnClickListener() { // handles buttons
            @Override
            public void onClick(View view) {
                String name = addItem.getText().toString();
                String quantityText = addQuantity.getText().toString();
                String categoryName = addCategory.getText().toString();
                if (name.isEmpty() || quantityText.isEmpty() || categoryName.isEmpty()) {
                    Toast.makeText(InventoryActivity.this, "Please enter the item name and quantity along with a category", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!quantityText.matches("\\d+")) { // error message for invalid input
                    Toast.makeText(InventoryActivity.this, "Error, must be a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                int quantity = Integer.parseInt(quantityText);
                long categoryId = database.getCategoryId(categoryName);
                if (categoryId == -1) {
                    Toast.makeText(InventoryActivity.this, "Category does not exist.", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean inserted = database.addItem(name, quantity, categoryId);
                if (inserted) {
                    Toast.makeText(InventoryActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                    if (quantity <= 5) {
                        SmsManager.getDefault().sendTextMessage("0123456789", null, "Alert! You have item(s) low in stock.", null, null);
                    }
                    addItem.setText("");
                    addQuantity.setText("");
                    loadItems();
                } else {
                    Toast.makeText(InventoryActivity.this, "Item unable to be added. Please try again", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonAddCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String categoryName = addCategory.getText().toString();
                if (categoryName.isEmpty()) {
                    Toast.makeText(InventoryActivity.this, "Enter a Category Name ", Toast.LENGTH_SHORT).show();
                    return;
                }
                boolean inserted = database.addCategory(categoryName);
                if (inserted) {
                    Toast.makeText(InventoryActivity.this, "Category added successfully", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(InventoryActivity.this, "Category unable to be added. Please try again", Toast.LENGTH_SHORT).show();
                }
            }
        });


        buttonLogout.setOnClickListener(new View.OnClickListener() { // sends user to login screen
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        buttonSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sortItems();
            }
        });
    }

    private void sortItems() {
        Cursor cursor = database.sortItemsByQuantity();
        items.clear();
        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndex("id"));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            int quantity = cursor.getInt(cursor.getColumnIndex("quantity"));
            long categoryId = cursor.getLong(cursor.getColumnIndex("category_id"));

            items.add(new ItemModel(id, name, quantity, categoryId ));
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }
            private void loadItems() { // for loading items
                 Cursor cursor = database.getItems();
                 items.clear();
                 while (cursor.moveToNext()) {
                     long id = cursor.getLong(cursor.getColumnIndex("id"));
                     String name = cursor.getString(cursor.getColumnIndex("name"));
                     int quantity = cursor.getInt(cursor.getColumnIndex("quantity"));
                     long categoryId = cursor.getLong(cursor.getColumnIndex("category_id"));
                     items.add(new ItemModel(id, name, quantity, categoryId));
                 }
                 cursor.close();
                 adapter.notifyDataSetChanged();
             }
         }

