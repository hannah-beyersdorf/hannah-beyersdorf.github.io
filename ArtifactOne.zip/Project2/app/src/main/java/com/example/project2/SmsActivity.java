package com.example.project2;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.Manifest;



public class SmsActivity  extends AppCompatActivity {
    private Button enableSms; // button to enable SMS permission
    private Button backButton; // button to go back to home screen
    private ActivityResultLauncher<String> enablePermission; // used for requesting permission


@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_sms);
    enableSms = findViewById(R.id.enableSms);
    backButton = findViewById(R.id.backButton);

    enablePermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    Toast.makeText(this, "SMS Permission has been enabled.", Toast.LENGTH_SHORT).show(); // Message for SMS being enabled
                    sendSms();
                } else {
                    Toast.makeText(this, "SMS Permission is not enabled.", Toast.LENGTH_SHORT).show(); // Message for SMS not enabled


                }
            }
    );
    enableSms.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            requestPermission();
        }
    });

    backButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            finish();
        }
    });

}
private void requestPermission() { // used to request user permission
        enablePermission.launch(Manifest.permission.SEND_SMS);
    }
private void sendSms() { // used to send the SMS
    android.telephony.SmsManager.getDefault().sendTextMessage("0123456789", null, "SMS sent", null, null
    );

}
}