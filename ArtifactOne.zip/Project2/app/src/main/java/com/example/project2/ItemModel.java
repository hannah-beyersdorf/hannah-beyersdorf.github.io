package com.example.project2;

public class ItemModel {
    public long id;
    public String name;
    public int quantity;

    public ItemModel(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }
}
