package com.example.project2;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.widget.GridView;
import android.database.Cursor;
import android.widget.Toast;
import android.Manifest;
import android.telephony.SmsManager;
import java.util.ArrayList;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity; // for buttons and text
public class InventoryActivity extends AppCompatActivity{
private Button buttonAdd;
private Button buttonLogout;
private EditText addItem;
private GridView gridView;
private EditText addQuantity;
private InventoryHelper database;
private GridAdapter adapter;
private ArrayList<ItemModel> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_inventory);
            buttonAdd = findViewById(R.id.buttonAdd);
            buttonLogout = findViewById(R.id.buttonLogout);


            addItem = findViewById(R.id.addItem);
            gridView= findViewById(R.id.gridView);
            addQuantity= findViewById(R.id.addQuantity);

            items = new ArrayList<>();
            database = new InventoryHelper(this);

            adapter = new GridAdapter(this,items,database);
            gridView.setAdapter(adapter);
            loadItems();

            buttonAdd.setOnClickListener(new View.OnClickListener() { // handles buttons
                @Override
                public void onClick(View view) {
                    String name = addItem.getText().toString();
                    String quantityText = addQuantity.getText().toString();
                    if (name.isEmpty() || quantityText.isEmpty()) {
                        Toast.makeText(InventoryActivity.this, "Please enter the item name and quantity", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (!quantityText.matches("\\d+")) { // error message for invalid input
                        Toast.makeText(InventoryActivity.this, "Error, must be a number", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int quantity = Integer.parseInt(quantityText);
                    boolean inserted = database.addItem(name, quantity);
                    if (inserted) {
                        Toast.makeText(InventoryActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                        if (quantity <= 5) {
                            SmsManager.getDefault().sendTextMessage("0123456789", null, "Alert! You have item(s) low in stock.", null, null);
                        }
                        addItem.setText("");
                        addQuantity.setText("");
                        loadItems();
                    } else {
                        Toast.makeText(InventoryActivity.this, "Item unable to be added. Please try again", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            buttonLogout.setOnClickListener(new View.OnClickListener() { // sends user to login screen
                @Override
                public void onClick(View view) {
                    finish();
                }
            });
         }
         private void loadItems() { // for loading items
        Cursor cursor = database.getItems();
        items.clear();
        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndex("id"));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            int quantity = cursor.getInt(cursor.getColumnIndex("quantity"));
            items.add(new ItemModel(id, name, quantity));
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    }

