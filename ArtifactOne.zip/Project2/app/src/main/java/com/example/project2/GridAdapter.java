package com.example.project2;

import android.content.Context;
import android.widget.Button;
import android.widget.TextView;
import android.widget.BaseAdapter;
import java.util.ArrayList;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
public class GridAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<ItemModel> items; // used for item list
    private InventoryHelper database; // database helper

    public GridAdapter(Context context, ArrayList<ItemModel> items, InventoryHelper database) {
        this.context = context;
        this.items = items;
        this.database = database;
    }

    @Override
    public int getCount() {
        return items.size();
    } // for number of items

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.grid_items, parent, false);
        }
        ItemModel item = items.get(position);

        Button delete = convertView.findViewById(R.id.buttonDelete); // used to delete buttons from list
        Button update = convertView.findViewById(R.id.buttonUpdate); // used to update item quantities
        TextView textView = convertView.findViewById(R.id.itemName);
        TextView quantityView = convertView.findViewById(R.id.itemQuantity);
        textView.setText(item.name);
        quantityView.setText(String.valueOf(item.quantity));

        delete.setOnClickListener(view -> {
            if (database.deleteItem(item.id)) {
                items.remove(item);
                notifyDataSetChanged();
            }
        });
        update.setOnClickListener(view -> {
            int updateQuantity = item.quantity + 1; // adds 1 to item quantity
            if (database.updateItem(item.id, item.name, updateQuantity)) {
                item.quantity = updateQuantity;
                notifyDataSetChanged();
            }
    });
        return convertView;
        }
    }


