package com.example.project2;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText nameText;
    private EditText passwordText;
    private TextView textGreeting;
    private Button loginButton;
    private Button createButton;

    private InventoryHelper db; // database helper
    private Button smsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);
        db = new InventoryHelper(this);

        nameText = findViewById(R.id.userName);
        passwordText = findViewById(R.id.userPassword);
        textGreeting = findViewById(R.id.textGreeting);
        loginButton = findViewById(R.id.buttonLogin);
        createButton = findViewById(R.id.buttonCreateLogin);
        smsButton =findViewById(R.id.smsButton);

        createButton.setOnClickListener(new View.OnClickListener() { // create user button
            @Override
            public void onClick(View v) {
                createUser();
            }
        });
        loginButton.setOnClickListener(new View.OnClickListener() { // login button
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        smsButton.setOnClickListener(new View.OnClickListener() { // SMS settings button
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SmsActivity.class);
                startActivity(intent);
            }
        });
    }
    private void createUser() {
        String username = nameText.getText().toString();
        String password = passwordText.getText().toString();
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter the username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean created = db.createUser(username, password);
        if (created) {
            Toast.makeText(this, "Success!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Unable to create new user", Toast.LENGTH_SHORT).show();
        }
    }
    private void loginUser() { // user login validation
        String username = nameText.getText().toString();
        String password = passwordText.getText().toString();
        boolean valid = db.loginUser(username, password);
        if (valid) {
            Toast.makeText(this, "Success!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(intent);

        }  else {
            Toast.makeText(this, "Invalid login. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}

